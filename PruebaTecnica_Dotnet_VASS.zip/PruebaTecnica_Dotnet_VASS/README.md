# PRUEBA TÉCNICA DESARROLLADOR .NET SENIOR

En el siguiente proyecto encontrará una minimal api para gestionar las preguntas que se reflejarán en un examen de cualquier temática deseada. Se requiere qué, usando una arquitectura limpia, implemente los siguiente requerimientos para un outsourcing de selección de candidatos, donde se evaluará los conocimientos técnicos de las personas mediante un examen de conocimientos.

## 1. Registrar Preguntas nuevas

Como Usuario, quiero agregar preguntas de opción múltiple con única respuesta, al repositorio y clasificarlas por temática para poder evaluar a los candidatos de acuerdo con el cargo al que están aplicando.

> *Criterios de Aceptación*

- Las preguntas deben persistir en el tiempo y no depender de si el servicio está detenido o no
  
- Las preguntas deben tener la siguiente estructura
    
    - Pregunta
    - Opciones de respuesta
    - Respuesta correcta
    - Puntaje de la pregunta
    - Temática

## 2. Eliminar una pregunta

Como usuario quiero, poder eliminar o marcar una pregunta como obsoleta de tal manera que no se borre de la base de datos pero que al consultar las preguntas, no se visualicen las que han sido marcadas como obsoletas

> *Criterios de Aceptación*

- El servicio debe marcar las preguntas en el repositorio como obsoletas
  
## 3. Consultar preguntas registradas

Como usuario quiero, consultar las preguntas que tengo configuradas  en mi repositorio, por temática

> *Criterios de Aceptación*

- El servicio debe permitir consultar las preguntas que se tienen hasta el momento configuradas y almacenadas en el repositorio

## CRITERIOS DE EVALUACIÓN

1. El código debe ser limpio
2. Implementación de una arquitectura limpia
3. El proyecto debe compilar y ejecutarse sin errores. (Actualmente el proyecto tiene errores de compilación y deberá corregirlos)
4. Implementación de Test unitarios automáticos (Al menos 2 test que validen la lógica de negocio)
5. Se valorará el uso de validaciones de datos entrada
6. Se valorará el uso de EntityFramework - Code First
7. El proyecto debe tener un control de versiones local para validar cada uno de los commits realizados
8. Uso de comentarios que agreguen valor. Evite los comentarios obvios. Si no son necesarios, no es requerido que el código tenga comentarios. Solo se valora si incluye comentarios donde estos puedan dar mayor entendimiento de la lógica implementada
9. Uso de principios de Desarrollo de software (SOLID, YARP, KISS, DRY, AAA,...)
10. Implementación de CORS (OPCIONAL)
11. Debe haber una documentación breve que explique como desplegar la aplicación
12. Cada uno de los endpoints debe ajustarse al archivo [Web.Api.Http](./src/Web.Api/Web.Api.http) para realizar las validaciones de la implementación.

## CONSIDERACIONES

- Usted es libre de utilizar las librerías que requiera para la implementación de los requerimientoss
- Debe usar idioma inglés en el estilo del código
- Todos los endpoints deben implementar la interfaz __IEndpoint__